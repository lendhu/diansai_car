#ifndef __TIME_H
#define __TIME_H

void Timer_Init(void);

#endif
