#include "sys.h"
#include "MG996R.h"
#include "MG51.h"
#include "Encode.h"
#include "usart.h"
#include "stdio.h"
#include "PID.h"
#include "delay.h"
#include "Encode_PID.h"
#include "led.h"
#include "KEY.h"
#include "OLED.h"
#include "openmv.h"
//extern uint8_t Serial_RxFlag;
//extern char Serial_RxPacket[];
//extern float speed1,speed2;

//float Data1,Data2;
//float PID[3]= {1600,20,0};
//float PID2[3]= {1700,25,10};

 int main(void)
 {	
	 PWM_Init();
//	 LED_Init();
//	 KEY_Init();
//	 Track_GPIOInit();
//	 delay_init();
//	 MG51_GPIOInit();
//	 MG51_PWMInit();
//	 MG51_LeftBMInit();
//	 MG51_RightBMInit();
//	 Encode_Init();
//	 OLED_Init();
//	 Serial_Init();
	 
//	 u8 t=0;	
//	 LED0=0;
//	 pid_type_def pid;
//	pid2_type_def pid2;
//	
//	PID_init(&pid,1,PID,1000,1000);
//	PID2_init(&pid2,1,PID2,1000,1000);
//	 
//	double speed_control=0;
   	while(1)
	{	
		PWM_SetCompare1(1500);
		PWM_SetCompare2(1500);
//		OLED_ShowString(2,1,"nihao");
//		if (Serial_GetRxFlag() == 1)
//		{
//			OLED_ShowString(3,1,"nihao");
//			//printf("%x",Serial_RxPacket[0]);
//			OLED_ShowHexNum(1,1,Serial_RxPacket[0],2);
//		}
//		Track_Control();
//		t=KEY_Scan(0);		//�õ���ֵ
//		Data1 = PID_calc(&pid,speed1,speed_control);
//		Data2 = PID2_calc(&pid2,speed2,speed_control);
//		PWM_ASet(Data1);
//		PWM_BSet(Data2);
		//printf("%f,%f,%f\n",speed1,speed2,0.3);
//		switch(t)
//		{				 
//			case KEY0_PRES:
//				LED0=!LED0;
//				MG51_Forward();
//				speed_control=0.3;
//				break;
//			case KEY1_PRES:
//				LED1=!LED1;
//				MG51_Forward();
//				speed_control=0.5;
//				break;
//			case WKUP_PRES:
//				MG51_Stop();
//				break;
//		} 		
	}
	
}
 

