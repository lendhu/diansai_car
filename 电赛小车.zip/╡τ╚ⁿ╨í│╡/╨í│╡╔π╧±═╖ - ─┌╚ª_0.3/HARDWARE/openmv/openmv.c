
#include "sys.h"
#include "stm32f10x.h"                  // Device header
#include "stdio.h"
#include "MG996R.h"
#include "Delay.h"

extern char Serial_RxPacket[];

void Openmv_Track_Control(void)
{
	if(Serial_RxPacket[0] == 0x9C)
	{
		PWM_SetCompare2(1600);
	}
	else if(Serial_RxPacket[0] ==0x7C)
	{
		PWM_SetCompare2(1600+100);
	}
	else if(Serial_RxPacket[0] ==0x1C)
	{
		PWM_SetCompare2(1600+200);
	}
	else if(Serial_RxPacket[0] ==0x2C)
	{
		PWM_SetCompare2(1600+300);
	}
	else if(Serial_RxPacket[0] ==0x3C)
	{
		PWM_SetCompare2(1600+400);
	}
	else if(Serial_RxPacket[0] ==0x8C)
	{
		PWM_SetCompare2(1600-100);
	}
	else if(Serial_RxPacket[0] ==0x4C)
	{
		PWM_SetCompare2(1600-200);
	}
	else if(Serial_RxPacket[0] ==0x5C)
	{
		PWM_SetCompare2(1600-300);
	}
	else if(Serial_RxPacket[0] ==0x6C)
	{
		PWM_SetCompare2(1600-550);
	}
	

}
