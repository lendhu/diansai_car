#ifndef __OPENMV_H
#define __OPENMV_H

void Openmv_Track_Control(void);
 
#endif

