#include "stm32f10x.h"                  // Device header
#include "MG51.h"

int16_t time2=0;
float speed1,speed2;

void Encode_Init(void)
{
	//һ������ʱ��
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4,ENABLE);
	//����ѡ��ʱ��Դ
	TIM_InternalClockConfig(TIM4);
	//��������ʱ����Ԫ
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInitStructure.TIM_Period = 100-1;
	TIM_TimeBaseInitStructure.TIM_Prescaler = 720-1;
	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM4,&TIM_TimeBaseInitStructure);
	
	TIM_ClearFlag(TIM4,TIM_FLAG_Update);//����ճ�ʼ�������ж�
	//�ģ��ж��������
	TIM_ITConfig(TIM4,TIM_IT_Update,ENABLE);
	//�壬����NVIC
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = TIM4_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
	NVIC_Init(&NVIC_InitStructure);
	//ʹ�ܶ�ʱ��
	TIM_Cmd(TIM4,ENABLE);
}

void TIM4_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM4, TIM_IT_Update) == SET)
	{
        time2++;
        if(time2==10)
        {
            speed1=(float)((float)Encoder_LeftGet()*0.2198/0.01/60000);
			speed2=(float)((float)Encoder_RightGet()*0.2198/0.01/60000);
            time2=0;
        }
		TIM_ClearITPendingBit(TIM4, TIM_IT_Update);
	}

}

