#include "MG51.h"

//����
//���Ʒ���
//PB0 AIN1
//PB1 AIN2
//PWM(0-1000)	��ʱ����ͨ��3 PA2
//������	��ʱ����  
//PA7 LA�� E1A
//PA6 LB�� E1B

//����
//���Ʒ���
//PA4 BIN1
//PA5 BIN2
//PWM(0-1000)	��ʱ����ͨ��4 BIN2 PA3
//������	��ʱ����
//PC6 RA�� E2A
//PC7 RB�� E2B

void PWM_ASet(unsigned int i)
{
	TIM_SetCompare3(TIM2,i);
}

void PWM_BSet(unsigned int i)
{
	TIM_SetCompare4(TIM2,i);
}

void MG51_GPIOInit(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);//����ʱ��
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);//����ʱ��
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.GPIO_Mode= GPIO_Mode_Out_PP;
	GPIO_InitStruct.GPIO_Pin= GPIO_Pin_0|GPIO_Pin_1;
	GPIO_InitStruct.GPIO_Speed= GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIO_InitStruct);//����
	
	GPIO_InitStruct.GPIO_Mode= GPIO_Mode_Out_PP;
	GPIO_InitStruct.GPIO_Pin= GPIO_Pin_4|GPIO_Pin_5;
	GPIO_InitStruct.GPIO_Speed= GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStruct);//����
}

void MG51_PWMInit(void)
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.GPIO_Mode= GPIO_Mode_AF_PP;
	GPIO_InitStruct.GPIO_Pin= GPIO_Pin_2|GPIO_Pin_3;
	GPIO_InitStruct.GPIO_Speed= GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStruct);//����
	
	TIM_InternalClockConfig(TIM2);
	
	TIM_TimeBaseInitTypeDef TIM_TimeInit;
	TIM_TimeInit.TIM_ClockDivision= TIM_CKD_DIV1;
	TIM_TimeInit.TIM_CounterMode= TIM_CounterMode_Up;
	TIM_TimeInit.TIM_Period= 1000-1;//ARR
	TIM_TimeInit.TIM_Prescaler= 1-1;//PSC
	TIM_TimeInit.TIM_RepetitionCounter= 0;
	TIM_TimeBaseInit(TIM2,&TIM_TimeInit);
	
	TIM_OCInitTypeDef TIM_OCInitStruct; 
	TIM_OCStructInit(&TIM_OCInitStruct);
	TIM_OCInitStruct.TIM_OCMode= TIM_OCMode_PWM1;
	TIM_OCInitStruct.TIM_OCPolarity= TIM_OCPolarity_High;
	TIM_OCInitStruct.TIM_OutputState= TIM_OutputState_Enable;
	TIM_OCInitStruct.TIM_Pulse=0;//CCR
	TIM_OC3Init(TIM2,&TIM_OCInitStruct);
	TIM_OC4Init(TIM2,&TIM_OCInitStruct);
	
	TIM_Cmd(TIM2,ENABLE);
}

void MG51_Forward(void)
{
	GPIO_WriteBit(GPIOB,GPIO_Pin_0,Bit_RESET);
	GPIO_WriteBit(GPIOB,GPIO_Pin_1,Bit_SET);
	GPIO_WriteBit(GPIOA,GPIO_Pin_4,Bit_RESET);
	GPIO_WriteBit(GPIOA,GPIO_Pin_5,Bit_SET);
}

void MG51_Stop(void)
{
	PWM_ASet(0);
	PWM_BSet(0);
	GPIO_WriteBit(GPIOB,GPIO_Pin_0,Bit_SET);
	GPIO_WriteBit(GPIOB,GPIO_Pin_1,Bit_SET);
	GPIO_WriteBit(GPIOA,GPIO_Pin_4,Bit_SET);
	GPIO_WriteBit(GPIOA,GPIO_Pin_5,Bit_SET);
}

void MG51_Back(void)
{
	PWM_ASet(300);
	PWM_BSet(300);
	GPIO_WriteBit(GPIOB,GPIO_Pin_0,Bit_RESET);
	GPIO_WriteBit(GPIOB,GPIO_Pin_1,Bit_SET);
	GPIO_WriteBit(GPIOA,GPIO_Pin_4,Bit_RESET);
	GPIO_WriteBit(GPIOA,GPIO_Pin_5,Bit_SET);
}

void MG51_Leftforward(void)
{
	PWM_ASet(300);
	PWM_BSet(300);
	GPIO_WriteBit(GPIOB,GPIO_Pin_0,Bit_RESET);
	GPIO_WriteBit(GPIOB,GPIO_Pin_1,Bit_SET);
	GPIO_WriteBit(GPIOA,GPIO_Pin_4,Bit_SET);
	GPIO_WriteBit(GPIOA,GPIO_Pin_5,Bit_RESET);
}

void MG51_Rightforward(void)
{
	PWM_ASet(300);
	PWM_BSet(300);
	GPIO_WriteBit(GPIOB,GPIO_Pin_0,Bit_SET);
	GPIO_WriteBit(GPIOB,GPIO_Pin_1,Bit_RESET);
	GPIO_WriteBit(GPIOA,GPIO_Pin_4,Bit_RESET);
	GPIO_WriteBit(GPIOA,GPIO_Pin_5,Bit_SET);
}

void MG51_LeftBMInit(void)
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);//����ʱ��
	
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.GPIO_Mode= GPIO_Mode_IPU;
	GPIO_InitStruct.GPIO_Pin= GPIO_Pin_6|GPIO_Pin_7;
	GPIO_InitStruct.GPIO_Speed= GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStruct);//����
	
	TIM_TimeBaseInitTypeDef TIM_TimeInit;
	TIM_TimeInit.TIM_ClockDivision= TIM_CKD_DIV1;
	TIM_TimeInit.TIM_CounterMode= TIM_CounterMode_Up;
	TIM_TimeInit.TIM_Period= 65535-1;//ARR
	TIM_TimeInit.TIM_Prescaler=1-1;//PSC
	TIM_TimeInit.TIM_RepetitionCounter= 0;
	TIM_TimeBaseInit(TIM3,&TIM_TimeInit);
	
	TIM_ICInitTypeDef TIM_ICInitStructure;
	TIM_ICStructInit(&TIM_ICInitStructure);
	TIM_ICInitStructure.TIM_Channel =TIM_Channel_1;
	TIM_ICInitStructure.TIM_ICFilter= 0xF;
	TIM_ICInitStructure.TIM_ICPolarity= TIM_ICPolarity_Rising;
	
	TIM_EncoderInterfaceConfig(TIM3,TIM_EncoderMode_TI12,TIM_ICPolarity_Rising,TIM_ICPolarity_Rising);
	
	TIM_ICInit(TIM3,&TIM_ICInitStructure);
	
	
	TIM_Cmd(TIM3,ENABLE);
}

void MG51_RightBMInit(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM8,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);//����ʱ��
	
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.GPIO_Mode= GPIO_Mode_IPU;
	GPIO_InitStruct.GPIO_Pin= GPIO_Pin_6|GPIO_Pin_7;
	GPIO_InitStruct.GPIO_Speed= GPIO_Speed_50MHz;
	GPIO_Init(GPIOC,&GPIO_InitStruct);//����
	
	TIM_TimeBaseInitTypeDef TIM_TimeInit;
	TIM_TimeInit.TIM_ClockDivision= TIM_CKD_DIV1;
	TIM_TimeInit.TIM_CounterMode= TIM_CounterMode_Up;
	TIM_TimeInit.TIM_Period= 65535-1;//ARR
	TIM_TimeInit.TIM_Prescaler= 1-1;//PSC
	TIM_TimeInit.TIM_RepetitionCounter= 0;
	TIM_TimeBaseInit(TIM8,&TIM_TimeInit);
	
	TIM_ICInitTypeDef YIM_ICInitStructure;
	TIM_ICStructInit(&YIM_ICInitStructure);
	YIM_ICInitStructure.TIM_Channel =TIM_Channel_1;
	YIM_ICInitStructure.TIM_ICFilter= 0xF;
	YIM_ICInitStructure.TIM_ICPolarity= TIM_ICPolarity_Rising;
	
	TIM_EncoderInterfaceConfig(TIM8,TIM_EncoderMode_TI12,TIM_ICPolarity_Rising,TIM_ICPolarity_Rising);
	
	TIM_ICInit(TIM8,&YIM_ICInitStructure);
	
	
	TIM_Cmd(TIM8,ENABLE);
}

uint16_t Encoder_LeftGet(void)
{	
	int16_t Temp;
	Temp=TIM_GetCounter(TIM3);
	TIM_SetCounter(TIM3,0);
	return Temp;

}

uint16_t Encoder_RightGet(void)
{	
	int16_t Temp;
	Temp=TIM_GetCounter(TIM8);
	TIM_SetCounter(TIM8,0);
	return Temp;
}


