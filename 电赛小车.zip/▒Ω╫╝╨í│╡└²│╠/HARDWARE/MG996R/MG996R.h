#ifndef __MG996R_H
#define __MG996R_H
#include "sys.h"

void PWM_Init(void);
void PWM_SetCompare2(uint16_t Compare);

#endif
