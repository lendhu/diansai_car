#ifndef __MG51_H__
#define __MG51_H__

#include "sys.h"

void PWM_ASet(unsigned int i);
void PWM_BSet(unsigned int i);
void MG51_GPIOInit(void);
void MG51_PWMInit(void);
void MG51_Forward(void);
void MG51_Back(void);
void MG51_Leftforward(void);
void MG51_Rightforward(void);
void MG51_Stop(void);
void MG51_LeftBMInit(void);
void MG51_RightBMInit(void);
uint16_t Encoder_LeftGet(void);
uint16_t Encoder_RightGet(void);
#endif

