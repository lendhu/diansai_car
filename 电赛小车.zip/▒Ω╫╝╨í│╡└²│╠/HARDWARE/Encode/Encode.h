#ifndef __ENCODE_H__
#define __ENCODE_H__

void Encode_Init(void);
#endif

