#include "sys.h"
#include "MG996R.h"
#include "MG51.h"
#include "Encode.h"
#include "usart.h"
#include "stdio.h"
#include "PID.h"
#include "delay.h"
#include "Encode_PID.h"
#include "led.h"
#include "KEY.h"

extern uint8_t Serial_RxFlag;
extern char Serial_RxPacket[];
extern int num;
float Data1,Data2;
float PID[3]= {2400,50,10};
float PID2[3]= {2400,50,10};
int num=0;
extern float speed1,speed2;

void Openmv_Track_Control(void)
{
	if(Serial_RxPacket[0]<=0X82&&Serial_RxPacket[0]>=0X3c)
	{
				num=Serial_RxPacket[0]-90;
		PWM_SetCompare2(1650 + 7.5*num);
	}else
	{
			if(Serial_RxPacket[0]>=0X82)
			{
					PWM_SetCompare2(2200);
			}else
			{
				PWM_SetCompare2(1100);	
			}
	}
}
 int main(void)
 {	
	 PWM_Init();
	 LED_Init();
	 KEY_Init();
	 Track_GPIOInit();
	 delay_init();
	 MG51_GPIOInit();
	 MG51_PWMInit();
	 MG51_LeftBMInit();
	 MG51_RightBMInit();
	 Encode_Init();
	 Serial_Init();
	 Serial_RxPacket[0]=0x5a;
	 
	 u8 t=0;	
	 LED0=0;
	 pid_type_def pid;
	 pid2_type_def pid2;
	
	 PID_init(&pid,1,PID,1000,1000);
	 PID2_init(&pid2,1,PID2,1000,1000);
	 double speed_control=0;
	 //MG51_Forward();
   	while(1)
	{
		Track_Control();
		//Track_ptintf();
		//Openmv_Track_Control();
		t=KEY_Scan(0);		//�õ���ֵ
		//delay_us(1000);
		//11PWM_SetCompare2(1650);
		//MG51_Forward();
		//printf("%d\r\n",num);
		//printf ("%d\r\n",Encoder_LeftGet());
		//MG51_Forward();
		Data1 = PID_calc(&pid,speed1,speed_control);
		Data2 = PID2_calc(&pid2,speed2,speed_control);
		PWM_ASet(Data1);
		PWM_BSet(Data2);

		printf("%f,%f,%f\r\n",speed1,speed2,speed_control);
		switch(t)
		{				 
			case KEY0_PRES:
				LED0=!LED0;
				speed_control=0.1;
				MG51_Forward();
				break;
			case KEY1_PRES:
				LED1=!LED1;
				speed_control=0.3;
				MG51_Forward();
				break;
			case WKUP_PRES:
				MG51_Stop();
				break;
		} 		
	}
	
}
 
 

