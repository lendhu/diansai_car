#include "sys.h"
#include "stm32f10x.h"                  // Device header
#include "stdio.h"
#include "Encode_PID.h"
#include "MG996R.h"
#include "Delay.h"


#define L2 GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_10)
#define L1 GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_3)
#define M0 GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_2)
#define R1 GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_0)
#define R2 GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_13)

float KP =10,KI=7,KD=0;

void Track_GPIOInit(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);//����ʱ��
	
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.GPIO_Mode= GPIO_Mode_IPD;
	GPIO_InitStruct.GPIO_Pin= GPIO_Pin_10|GPIO_Pin_3|GPIO_Pin_2|GPIO_Pin_0|GPIO_Pin_13;
	GPIO_InitStruct.GPIO_Speed= GPIO_Speed_50MHz;
	GPIO_Init(GPIOC,&GPIO_InitStruct);
	
}

void Track_ptintf(void)
{
	printf("%d %d %d %d %d\r\n",L2,L1,M0,R1,R2);
}

float Track_Output(void)
{
	float error,last_error;//�˴κ��ϴε����
	static float integral;//�����ۼ���
	float output;
	
	if((L1 ==1)&&(M0 == 0)&&(R1 == 0))
	{
		error =-0.2;
	}
	else if((L1 ==0)&&(M0 == 1)&&(R1 == 0))
	{
		error =0;output=0;last_error=0;integral=0;
	}
	else if((L1 ==0)&&(M0 == 0)&&(R1 == 1))
	{
		error =+0.2;
	}
	
	integral +=error;
	
	output =KP*error + KI * integral +KD * (error - last_error);
	
	last_error =error;
	
	printf("%f\r\n",output);
	
	if(output>450)
	{
		output=450;
	}
	if(output<-450)
	{
		output=-450;
	}
	return output;
}

void Track_Control(void)
{
	if((L1 ==1)&&(M0 == 0)&&(R1 == 0))
	{
		PWM_SetCompare2(1650+Track_Output());
	}
//	else if((L2 ==1)&&(L1 ==0)&&(M0 == 0)&&(R1 == 0))
//	{
//		PWM_SetCompare2(1650-450);
//		delay_ms(300);
//	}
	else if((L1 ==0)&&(M0 == 1)&&(R1 == 0)&&(R2 == 0)&&(L2 == 0))
	{
		PWM_SetCompare2(1650+Track_Output());
	}
	else if((L1 ==0)&&(M0 == 0)&&(R1 == 1))
	{
		PWM_SetCompare2(1650+Track_Output());
	}
	else if((L1 ==0)&&(M0 == 0)&&(R1 == 0)&&(R2==1))
	{
		PWM_SetCompare2(1650+450);
	}

}


